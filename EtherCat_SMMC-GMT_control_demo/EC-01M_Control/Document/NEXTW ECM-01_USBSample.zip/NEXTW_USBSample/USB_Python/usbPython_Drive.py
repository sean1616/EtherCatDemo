import ctypes
import time
from ctypes import *
ll = ctypes.windll.LoadLibrary
lib_test = ll("./NEXTWUSBLib.dll")

class transData (Structure):
    _fields_ = [("CMD", c_ushort),
                ("Parm", c_ushort),
                ("Data1", c_uint),
                ("Data2", c_uint)]

#macros
DEF_MA_MAX = 42
NIC_INIT = 0
STATE_INIT = 1
STATE_PRE_OP = 2
STATE_SAFE_OP = 4
STATE_OPERATIONAL = 8
SET_STATE = 0x01
SET_AXIS = 0x02
SET_DC = 0x03
DRIVE_MODE = 0x06
SV_ON = 0x11
SV_OFF = 0x12
IO_WR = 0x14
CSP = 0x15

CSP_MODE = 8
FREERUN = 0x00
DCSYNC = 0x01

DRIVE = 0x0
IO = 0x1
NONE = 0xF
#funtions
def ClearCmdData(data):
    for i in range(DEF_MA_MAX):
        data[i].CMD = c_ushort(0)
        data[i].Parm = c_ushort(0)
        data[i].Data1 = c_uint(0)
        data[i].Data2 = c_uint(0)
#variables
retValue = False
isOpen = False
cmdData = (transData*DEF_MA_MAX)()
respData = (transData*DEF_MA_MAX)()
#print (ctypes.sizeof(cmdData))

retValue = lib_test.OpenECMUSB()
if retValue != 0:
    isOpen = True
else:
    print('Open USB Fail')
    quit()
time.sleep(0.1)
print('Set PREOP state')
ClearCmdData(cmdData)
cmdData[0].CMD = SET_STATE
cmdData[0].Data1 = STATE_PRE_OP
lib_test.ECMUSBWrite(byref(cmdData),c_ulong(ctypes.sizeof(cmdData)))
print('Set axis')
time.sleep(1)
ClearCmdData(cmdData)
slaveType = [DRIVE]*4 + [NONE]*36
topology = 0
for i in range(1,6):
    for j in range(8*(i-1),8*i):
        topology |= (slaveType[j] << (j%8)*4)
    cmdData[0].CMD = c_ushort(SET_AXIS)
    cmdData[0].Parm = c_ushort(i-1)
    cmdData[0].Data1 = c_uint(topology)
    cmdData[0].Data2 = c_uint(0)
    lib_test.ECMUSBWrite(byref(cmdData),c_ulong(ctypes.sizeof(cmdData)))
    time.sleep(0.01)
print('Set DC')
ClearCmdData(cmdData)
cmdData[0].CMD = c_ushort(SET_DC)
cmdData[0].Parm = c_ushort(0)
cmdData[0].Data1 = c_uint(4000)
cmdData[0].Data2 = c_uint(0xffff)
lib_test.ECMUSBWrite(byref(cmdData),c_ulong(ctypes.sizeof(cmdData)))
time.sleep(0.01)
print('Set drive mode')
ClearCmdData(cmdData)
for i in range(1,DEF_MA_MAX-1):
    if slaveType[i-1] == DRIVE :
        cmdData[i].CMD = c_ushort(DRIVE_MODE)
        cmdData[i].Data1 = c_uint(CSP_MODE)
        cmdData[i].Data2 = c_uint(DCSYNC)
lib_test.ECMUSBWrite(byref(cmdData),c_ulong(ctypes.sizeof(cmdData)))
time.sleep(0.01)
print('Set SAFEOP state')
ClearCmdData(cmdData)
cmdData[0].CMD = c_ushort(SET_STATE)
cmdData[0].Data1 = c_uint(STATE_SAFE_OP)
lib_test.ECMUSBWrite(byref(cmdData),c_ulong(ctypes.sizeof(cmdData)))
time.sleep(3)
print('Set OP state')
ClearCmdData(cmdData)
cmdData[0].CMD = c_ushort(SET_STATE)
cmdData[0].Data1 = c_uint(STATE_OPERATIONAL)
lib_test.ECMUSBWrite(byref(cmdData),c_ulong(ctypes.sizeof(cmdData)))
time.sleep(1)
print('Servo on')
ClearCmdData(cmdData)
for i in range(1,DEF_MA_MAX-1):
    if slaveType[i-1] == DRIVE :
        cmdData[i].CMD = SV_ON
lib_test.ECMUSBWrite(byref(cmdData),c_ulong(ctypes.sizeof(cmdData)))
time.sleep(1)
TargerPosition = [c_int(0)]*DEF_MA_MAX
lib_test.ECMUSBRead(byref(cmdData),c_ulong(ctypes.sizeof(cmdData)))
for i in range(1,DEF_MA_MAX-1):
    TargerPosition[i] = cmdData[i].Data1
time.sleep(1)
ClearCmdData(cmdData);
for i in range(1000):	
    for j in range(1,DEF_MA_MAX-1):
        if slaveType[j-1] == DRIVE :
            TargerPosition[j] += 100
            cmdData[j].CMD = c_ushort(CSP)
            cmdData[j].Data1 = c_uint(TargerPosition[j])
    lib_test.ECMUSBWrite(byref(cmdData),c_ulong(ctypes.sizeof(cmdData)))
    if i % 2 == 0 :
        lib_test.ECMUSBRead(byref(respData),c_ulong(ctypes.sizeof(respData)))
        if ((respData[0].Data2 % 65536)<80) :
            time.sleep(0.01)

lib_test.ECMUSBWrite(byref(cmdData),c_ulong(ctypes.sizeof(cmdData)))
time.sleep(3)
lib_test.CloseECMUSB()
print('End Test')

import ctypes
import time
from ctypes import *
ll = ctypes.windll.LoadLibrary
lib_test = ll("./NEXTWUSBLib.dll")

class transData (Structure):
    _fields_ = [("CMD", c_ushort),
                ("Parm", c_ushort),
                ("Data1", c_uint),
                ("Data2", c_uint)]

#macros
DEF_MA_MAX = 42
NIC_INIT = 0
STATE_INIT = 1
STATE_PRE_OP = 2
STATE_SAFE_OP = 4
STATE_OPERATIONAL = 8
SET_STATE = 0x01
SET_AXIS = 0x02
SET_DC = 0x03
IO_WR = 0x14
IO = 0x1
NONE = 0xF
#funtions
def ClearCmdData(data):
    for i in range(DEF_MA_MAX):
        data[i].CMD = c_ushort(0)
        data[i].Parm = c_ushort(0)
        data[i].Data1 = c_uint(0)
        data[i].Data2 = c_uint(0)
#variables
retValue = False
isOpen = False
cmdData = (transData*DEF_MA_MAX)()
respData = (transData*DEF_MA_MAX)()
#print (ctypes.sizeof(cmdData))

retValue = lib_test.OpenECMUSB()
if retValue != 0:
    isOpen = True;
else:
    print('Open USB Fail')
    quit()
time.sleep(0.1)
print('Set PREOP state')
ClearCmdData(cmdData)
cmdData[0].CMD = SET_STATE
cmdData[0].Data1 = STATE_PRE_OP
lib_test.ECMUSBWrite(byref(cmdData),c_ulong(ctypes.sizeof(cmdData)))
print('Set axis')
time.sleep(1)
ClearCmdData(cmdData)
slaveType = [IO] + [NONE]*39
topology = 0
for i in range(1,6):
    for j in range(8*(i-1),8*i):
        topology |= (slaveType[j] << (j%8)*4)
    cmdData[0].CMD = c_ushort(SET_AXIS)
    cmdData[0].Parm = c_ushort(i-1)
    cmdData[0].Data1 = c_uint(topology)
    cmdData[0].Data2 = c_uint(0)
    lib_test.ECMUSBWrite(byref(cmdData),c_ulong(ctypes.sizeof(cmdData)))
    time.sleep(0.01)
print('Set DC')
ClearCmdData(cmdData)
cmdData[0].CMD = c_ushort(SET_DC)
cmdData[0].Parm = c_ushort(0)
cmdData[0].Data1 = c_uint(2000)
cmdData[0].Data2 = c_uint(0xffff)
lib_test.ECMUSBWrite(byref(cmdData),c_ulong(ctypes.sizeof(cmdData)))
time.sleep(0.01)
print('Set SAFEOP state')
ClearCmdData(cmdData)
cmdData[0].CMD = c_ushort(SET_STATE)
cmdData[0].Data1 = c_uint(STATE_SAFE_OP)
lib_test.ECMUSBWrite(byref(cmdData),c_ulong(ctypes.sizeof(cmdData)))
time.sleep(3)
print('Set OP state')
ClearCmdData(cmdData)
cmdData[0].CMD = c_ushort(SET_STATE)
cmdData[0].Data1 = c_uint(STATE_OPERATIONAL)
lib_test.ECMUSBWrite(byref(cmdData),c_ulong(ctypes.sizeof(cmdData)))
time.sleep(1)
for i in range(100):
    ClearCmdData(cmdData)
    cmdData[1].CMD = c_ushort(IO_WR)
    cmdData[1].Data1 = c_uint(i)
    lib_test.ECMUSBWrite(byref(cmdData),c_ulong(ctypes.sizeof(cmdData)))
    time.sleep(1)
time.sleep(3)
lib_test.CloseECMUSB()
print('End Test')
